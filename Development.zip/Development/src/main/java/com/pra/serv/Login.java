package com.pra.serv;

import java.io.IOException;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class Login extends HttpServlet {
	String query="select * from register where email=? and password=?";
	String un="jdbc:mysql://localhost:3306/event";
	String root="root";
	String pd="1234";
	Connection conn=null;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String name=req.getParameter("email");
			String pwd=req.getParameter("password");
			conn=DriverManager.getConnection(un,root,pd);
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, name);
			ps.setString(2, pwd);
			ResultSet rs=ps.executeQuery();
			if(rs!=null) {
				resp.sendRedirect("welcome.html");	
			}
			else {
				resp.getWriter().println("Something went wrong");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}

