package com.pra.serv;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class Register extends HttpServlet{
	String uname="jdbc:mysql://localhost:3306/event"; 
	String root="root";
	String pwd="1234";
	Connection conn=null;
	String query="insert into register(name,email,password) values (?,?,?)";

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection(uname,root,pwd);
			PreparedStatement ps=conn.prepareStatement(query);
			PrintWriter pw=resp.getWriter();
			String name=req.getParameter("name");
			String mail=req.getParameter("email");
			String pwd=req.getParameter("password");
			ps.setString(1, name);
			ps.setString(2, mail);
			ps.setString(3, pwd);
			int x=ps.executeUpdate();
			if(x!=0) {
				resp.sendRedirect("success.html");
				
			}
			else {
				resp.getWriter().println("Something went wrong");
			}
			
//			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}